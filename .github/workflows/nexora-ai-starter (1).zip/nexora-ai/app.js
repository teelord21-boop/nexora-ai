const navItems=document.querySelectorAll('.nav-item[data-section]');
const currentSection=document.getElementById('currentSection');
const sidebar=document.getElementById('sidebar');
const mobileMenu=document.getElementById('mobileMenu');
const chatForm=document.getElementById('chatForm');
const chatInput=document.getElementById('chatInput');
const chatBody=document.getElementById('chatBody');
const newChat=document.getElementById('newChat');

navItems.forEach(item=>item.addEventListener('click',()=>{
  navItems.forEach(n=>n.classList.remove('active'));
  item.classList.add('active');
  currentSection.textContent=item.dataset.section;
  sidebar.classList.remove('open');
}));
mobileMenu?.addEventListener('click',()=>sidebar.classList.toggle('open'));

function addMessage(text,type='assistant'){
  const el=document.createElement('div');
  el.className=`message ${type}`;
  el.textContent=text;
  chatBody.appendChild(el);
  chatBody.scrollTop=chatBody.scrollHeight;
}

chatForm.addEventListener('submit',e=>{
  e.preventDefault();
  const text=chatInput.value.trim();
  if(!text)return;
  addMessage(text,'user');
  chatInput.value='';
  setTimeout(()=>addMessage('I’m ready to help. Connect your preferred AI provider through a secure backend to enable live AI responses.'),350);
});

document.querySelectorAll('.feature-card').forEach(card=>card.addEventListener('click',()=>{
  chatInput.value=card.dataset.prompt;
  chatInput.focus();
}));
newChat.addEventListener('click',()=>{
  chatBody.innerHTML='';
  addMessage('New conversation started. What would you like to build?');
  chatInput.focus();
});
